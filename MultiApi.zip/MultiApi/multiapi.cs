using System;

using System.Net.Http;

using System.Net.Http.Headers;

using System.Threading.Tasks;

using Microsoft.Identity.Client;

class Program
{
    private static string clientId = "YOUR_CLIENT_ID";

    private static string tenantId = "YOUR_TENANT_ID";

    private static string clientSecret = "YOUR_CLIENT_SECRET";

    private static string authority = $"https://login.microsoftonline.com/{tenantId}";

    private static string scope = "api://YOUR_API_ID/.default";

    private static string apiUrl = "https://YOUR_API.azurewebsites.net/api/yourendpoint";

    static async Task Main(string[] args)
    {
        var accessToken = await GetAccessToken();
        await CallApi(accessToken);
    }
    private static async Task<string> GetAccessToken()
    {
        IConfidentialClientApplication app = ConfidentialClientApplicationBuilder.Create(clientId).WithClientSecret(clientSecret).WithAuthority(new Uri(authority)).Build();
        var result = await app.AcquireTokenForClient(new[] { scope }).ExecuteAsync();
        return result.AccessToken;
    }
    private static async Task CallApi(string accessToken)
    {
        using (var httpClient = new HttpClient())
        {
            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            var response = await httpClient.GetAsync(apiUrl);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                Console.WriteLine("API Response: " + content);
            }
            else
            {
                Console.WriteLine("Error: " + response.StatusCode);
            }
        }
    }
}